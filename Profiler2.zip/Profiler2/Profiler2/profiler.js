//modal code
$(document).ready(function() 
{ 
$("#myModal").modal('hide'); 
}); 

//popover  code
$(function(){
$('[data-toggle="popover"]').popover ()
})

//tooltip code
$(function(){
$('[data-toggle="tooltip"]').tooltip()
})

//toggle question code 1
$(document).ready(function() 
{ 

$("#shbtn1").click(function() 
{ 

$("#d1").toggle(); 

}); 

}); 

//toggle question code 2
$(document).ready(function() 
{ 

$("#shbtn2").click(function() 
{ 

$("#d2").toggle(); 

}); 

}); 

//toggle question code 3
$(document).ready(function() 
{ 

$("#shbtn3").click(function() 
{ 

$("#d3").toggle(); 

}); 

}); 

//toggle question code 4
$(document).ready(function() 
{ 

$("#shbtn4").click(function() 
{ 

$("#d4").toggle(); 

}); 

}); 

//toggle question code 5
$(document).ready(function() 
{ 

$("#shbtn5").click(function() 
{ 

$("#d5").toggle(); 

}); 

}); 

//toggle question code 6
$(document).ready(function() 
{ 

$("#shbtn6").click(function() 
{ 

$("#d6").toggle(); 

}); 

}); 

//toggle question code 7
$(document).ready(function() 
{ 

$("#shbtn7").click(function() 
{ 

$("#d7").toggle(); 

}); 

}); 

//toggle question code 8
$(document).ready(function() 
{ 

$("#shbtn8").click(function() 
{ 

$("#d8").toggle(); 

}); 

}); 

$(document).ready(function(){
$("h5").animate({
color: "teal"
});
});

$(document).ready (function(){
$("img").attr("loading", "lazy");
});

//speech module profiler component 
//speech 0
function profiler0() {
  // Create a SpeechSynthesisUtterance
  const utterance = new SpeechSynthesisUtterance("This user interface component is easy to use, created mobile phone first you can edit and run it on your smart phone, alternatively with a little knowledge you can deploy your work on the Internet. You does not need any programming knowledge to use this component, by logically following the instructions provided in this documentation,  you can almost  create profiles on any subject of your interest, from prominent people, celebrities in all fields to animals and plants, it can serve as a classification system of some sort. The component is for purpose of learning web programming,  it is free you can change it, modify it or share it, in accordance  with terms of service. For more details view the documentation file .");
  // Select a voice
  const voices = speechSynthesis.getVoices();
  utterance.voice = voices[0]; // Choose a specific voice
  // Speak the text
  speechSynthesis.speak(utterance);
}
//end of speech 0

//speech 1
function profiler1() {
  // Create a SpeechSynthesisUtterance
  const utterance = new SpeechSynthesisUtterance("This component is easy to use, created mobile first you can edit and run it on your smartphone, alternatively with a little knowledge you can deploy your art on the Internet. You does not need any programming knowledge to use this component, by meticulously following instructions provided in this documentation,  you can almost  create profiles on any subject of your interest. The component is for purpose of learning web programming,  it is free you can change it, manipulate it or share it, in accordance  with terms of service. The component is a user interface, and can be used to build profiles on various subjects, from prominent people, celebrities in all fields to animals and plants, it can serve as a classification system of some sort.");
  // Select a voice
  const voices = speechSynthesis.getVoices();
  utterance.voice = voices[0]; // Choose a specific voice
  // Speak the text
  speechSynthesis.speak(utterance);
}
//end of speech 1

//speech 2
function profiler2() {
  // Create a SpeechSynthesisUtterance
  const utterance = new SpeechSynthesisUtterance("This component is easy to use, created mobile first you can edit and run it on your smartphone, alternatively with a little knowledge you can deploy your art on the Internet. You does not need any programming knowledge to use this component, by meticulously following instructions provided in this documentation,  you can almost  create profiles on any subject of your interest. The component is for purpose of learning web programming,  it is free you can change it, manipulate it or share it, in accordance  with terms of service. The component is a user interface, and can be used to build profiles on various subjects, from prominent people, celebrities in all fields to animals and plants, it can serve as a classification system of some sort.");
  // Select a voice
  const voices = speechSynthesis.getVoices();
  utterance.voice = voices[0]; // Choose a specific voice
  // Speak the text
  speechSynthesis.speak(utterance);
}
//end of speech 2

//speech 3
function profiler3() {
  // Create a SpeechSynthesisUtterance
  const utterance = new SpeechSynthesisUtterance("This component is easy to use, created mobile first you can edit and run it on your smartphone, alternatively with a little knowledge you can deploy your art on the Internet. You does not need any programming knowledge to use this component, by meticulously following instructions provided in this documentation,  you can almost  create profiles on any subject of your interest. The component is for purpose of learning web programming,  it is free you can change it, manipulate it or share it, in accordance  with terms of service. The component is a user interface, and can be used to build profiles on various subjects, from prominent people, celebrities in all fields to animals and plants, it can serve as a classification system of some sort.");
  // Select a voice
  const voices = speechSynthesis.getVoices();
  utterance.voice = voices[0]; // Choose a specific voice
  // Speak the text
  speechSynthesis.speak(utterance);
}
//end of speech 3

//speech 4
function profiler4() {
  // Create a SpeechSynthesisUtterance
  const utterance = new SpeechSynthesisUtterance("This component is easy to use, created mobile first you can edit and run it on your smartphone, alternatively with a little knowledge you can deploy your art on the Internet. You does not need any programming knowledge to use this component, by meticulously following instructions provided in this documentation,  you can almost  create profiles on any subject of your interest. The component is for purpose of learning web programming,  it is free you can change it, manipulate it or share it, in accordance  with terms of service. The component is a user interface, and can be used to build profiles on various subjects, from prominent people, celebrities in all fields to animals and plants, it can serve as a classification system of some sort.");
  // Select a voice
  const voices = speechSynthesis.getVoices();
  utterance.voice = voices[0]; // Choose a specific voice
  // Speak the text
  speechSynthesis.speak(utterance);
}
//end of speech 4


//speech 5
function profiler5() {
  // Create a SpeechSynthesisUtterance
  const utterance = new SpeechSynthesisUtterance("This component is easy to use, created mobile first you can edit and run it on your smartphone, alternatively with a little knowledge you can deploy your art on the Internet. You does not need any programming knowledge to use this component, by meticulously following instructions provided in this documentation,  you can almost  create profiles on any subject of your interest. The component is for purpose of learning web programming,  it is free you can change it, manipulate it or share it, in accordance  with terms of service. The component is a user interface, and can be used to build profiles on various subjects, from prominent people, celebrities in all fields to animals and plants, it can serve as a classification system of some sort.");
  // Select a voice
  const voices = speechSynthesis.getVoices();
  utterance.voice = voices[0]; // Choose a specific voice
  // Speak the text
  speechSynthesis.speak(utterance);
}
//end of speech 5

//speech 6
function profiler6() {
  // Create a SpeechSynthesisUtterance
  const utterance = new SpeechSynthesisUtterance("This component is easy to use, created mobile first you can edit and run it on your smartphone, alternatively with a little knowledge you can deploy your art on the Internet. You does not need any programming knowledge to use this component, by meticulously following instructions provided in this documentation,  you can almost  create profiles on any subject of your interest. The component is for purpose of learning web programming,  it is free you can change it, manipulate it or share it, in accordance  with terms of service. The component is a user interface, and can be used to build profiles on various subjects, from prominent people, celebrities in all fields to animals and plants, it can serve as a classification system of some sort.");
  // Select a voice
  const voices = speechSynthesis.getVoices();
  utterance.voice = voices[0]; // Choose a specific voice
  // Speak the text
  speechSynthesis.speak(utterance);
}
//end of speech 6

//speech 7
function profiler7() {
  // Create a SpeechSynthesisUtterance
  const utterance = new SpeechSynthesisUtterance("This component is easy to use, created mobile first you can edit and run it on your smartphone, alternatively with a little knowledge you can deploy your art on the Internet. You does not need any programming knowledge to use this component, by meticulously following instructions provided in this documentation,  you can almost  create profiles on any subject of your interest. The component is for purpose of learning web programming,  it is free you can change it, manipulate it or share it, in accordance  with terms of service. The component is a user interface, and can be used to build profiles on various subjects, from prominent people, celebrities in all fields to animals and plants, it can serve as a classification system of some sort.");
  // Select a voice
  const voices = speechSynthesis.getVoices();
  utterance.voice = voices[0]; // Choose a specific voice
  // Speak the text
  speechSynthesis.speak(utterance);
}
//end of speech 7
//end of speech module profiler component 

//quizz questions code 
function checkAnswer()
  {
   var totQuestion = 8;

   var ansQuestion = 0;

   var rightAns = 0;

   for (var i = 1; i <= totQuestion; i++)
   {
    var elem = document.getElementsByName("q" + i);

    for (var j = 0; j < elem.length; j++)
    {
     if (elem[j].checked)
     {

      ansQuestion++;

      if (elem[j].dataset.answer == 1)
      {
       rightAns++;
      }

     }
    }
   }

   if (ansQuestion != totQuestion)
   {
    alert("Please answer all questions");
   }
   else
   {
    alert("Your Score is " + rightAns + " Out Of " + totQuestion);
   }
  }
  //quizz question code end 
  